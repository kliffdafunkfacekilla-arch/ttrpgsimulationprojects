CREATE TABLE macro_groups (
    id SERIAL PRIMARY KEY,
    population FLOAT,
    chaos_level FLOAT,
    pressure FLOAT,
    magistar_id VARCHAR(255),
    is_active BOOLEAN,
    weather VARCHAR(255),
    geom GEOMETRY(Geometry, 4326) -- Using PostGIS standard representation
);

CREATE TABLE cells (
    id SERIAL PRIMARY KEY,
    geom GEOMETRY(Geometry, 4326)
);
