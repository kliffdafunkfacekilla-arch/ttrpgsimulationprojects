import { lineWeights } from "./lineWeights";

export const divisions = {
  variants: {
    perPale: 5,
    perFess: 5,
    perBend: 2,
    perBendSinister: 1,
    perChevron: 1,
    perChevronReversed: 1,
    perCross: 5,
    perPile: 1,
    perSaltire: 1,
    gyronny: 1,
    chevronny: 1
  },
  perPale: lineWeights,
  perFess: lineWeights,
  perBend: lineWeights,
  perBendSinister: lineWeights,
  perChevron: lineWeights,
  perChevronReversed: lineWeights,
  perCross: {
    straight: 20,
    wavy: 5,
    engrailed: 4,
    invecked: 3,
    rayonne: 1,
    embattled: 1,
    raguly: 1,
    urdy: 1,
    indented: 2,
    dentilly: 1,
    bevilled: 1,
    angled: 1,
    embattledGhibellin: 1,
    embattledGrady: 1,
    dovetailedIndented: 1,
    dovetailed: 1,
    potenty: 1,
    potentyDexter: 1,
    potentySinister: 1,
    nebuly: 1
  },
  perPile: lineWeights
};
