export const positions = {
  conventional: {
    e: 20,
    abcdefgzi: 3,
    beh: 3,
    behdf: 2,
    acegi: 1,
    kn: 3,
    bhdf: 1,
    jeo: 1,
    abc: 3,
    jln: 6,
    jlh: 3,
    kmo: 2,
    jleh: 1,
    def: 3,
    abcpqh: 4,
    ABCDEFGHIJKL: 1
  },
  complex: {
    e: 40,
    beh: 1,
    kn: 1,
    jeo: 1,
    abc: 2,
    jln: 7,
    jlh: 2,
    def: 1,
    abcpqh: 1
  },
  divisions: {
    perPale: { e: 15, pq: 5, jo: 2, jl: 2, ABCDEFGHIJKL: 1 },
    perFess: {
      e: 12,
      kn: 4,
      jkl: 2,
      gizgiz: 1,
      jlh: 3,
      kmo: 1,
      ABCDEFGHIJKL: 1
    },
    perBend: { e: 5, lm: 5, bcfdgh: 1 },
    perBendSinister: { e: 1, jo: 1 },
    perCross: { e: 4, jlmo: 1, j: 1, jo: 2, jl: 1 },
    perChevron: { e: 1, jlh: 1, dfk: 1, dfbh: 2, bdefh: 1 },
    perChevronReversed: { e: 1, mok: 2, dfh: 2, dfbh: 1, bdefh: 1 },
    perSaltire: { bhdf: 8, e: 3, abcdefgzi: 1, bh: 1, df: 1, ABCDEFGHIJKL: 1 },
    perPile: { ee: 3, be: 2, abceh: 1, abcabc: 1, jleh: 1 }
  },
  inescutcheon: { e: 4, jln: 1 }
};
